-- --------------------------------------
-- Inserción de los usuarios de prueba --
INSERT INTO `qvt-db`.`usuario` (`username`, `password`, `nombres`, `apellidos`, `email`) VALUES ('admin', 'admin', 'Admin', 'Test', 'admin@test.com');
INSERT INTO `qvt-db`.`usuario` (`username`, `password`, `nombres`, `apellidos`, `email`) VALUES ('jpsalas1', 'jpsalas1', 'Juan Pedro', 'Pérez Salas', 'jp.perez.salas@gmail.com');

-- --------------------------------------
-- Inserción de los Canales Nacionales --
INSERT INTO `qvt-db`.`canal` (`nombre`) VALUES ('Canal 13');
INSERT INTO `qvt-db`.`canal` (`nombre`) VALUES ('Chilevision');
INSERT INTO `qvt-db`.`canal` (`nombre`) VALUES ('MEGA');
INSERT INTO `qvt-db`.`canal` (`nombre`) VALUES ('TVN');

-- -------------------------------------------------------------------------------
-- Inserción de algunos programas transmitidos por sus correspondientes canales --
-- CANAL 13 --
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (1, 1, 'Bienvenidos', '08:00', '13:30');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (1, 1, 'Paramparça', '15:30', '17:00');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (1, 1, 'Entre dos amores', '17:00', '18:00');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (1, 1, 'Amor a segunda vista', '18:00', '19:10');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (1, 1, 'La pequeña casa en la pradera', '19:10', '21:00');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (1, 1, 'Vertigo', '22:35', '01:00');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (1, 1, 'Kosem', '22:35', '00:15');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (1, 1, 'MasterChef Chile', '23:30', '01:30');

-- CHILEVISION --
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (2, 2, 'La mañana', '08:00', '13:30');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (2, 2, 'La jueza', '15:30', '17:30');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (2, 2, 'Lo que callamos las mujeres', '17:30', '18:30');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (2, 2, 'Vidas en riesgo', '18:30', '19:30');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (2, 2, 'Caso cerrado', '19:30', '21:00');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (2, 2, 'Espías del amor', '22:30', '00:00');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (2, 2, 'Primer plano', '22:30', '00:30');

-- MEGA --
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (3, 1, 'Mucho gusto', '08:00', '13:00');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (3, 1, 'Amanda', '15:15', '16:30');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (3, 1, 'Sevda', '16:30', '17:15');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (3, 1, 'El regreso de Lucas', '17:15', '18:00');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (3, 1, 'El secreto de Feriha', '18:00', '20:15');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (3, 1, 'Tranquilo papá', '20:15', '21:00');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (3, 1, 'Perdona nuestros pecados', '22:30', '23:30');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (3, 1, 'Morandé con compañia', '22:30', '00:45');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (3, 1, 'Doble tentación', '23:30', '01:00');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (3, 1, 'Más vale tarde', '01:00', '02:00');

-- TVN --
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (4, 2, 'Muy buenos días', '08:00', '13:00');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (4, 2, 'Elif', '15:30', '17:15');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (4, 2, 'Saras y Kumud', '17:15', '18:30');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (4, 2, 'Günes', '18:30', '20:00');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (4, 2, 'La colombiana', '20:00', '21:00');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (4, 2, 'Match', '22:30', '00:15');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (4, 2, 'Hulya', '22:45', '23:30');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (4, 2, 'Josue y la tierra prometida', '23:30', '00:30');
INSERT INTO `qvt-db`.`programa` (`canal_id`, `usuario_id`, `nombre`, `inicio`, `termino`) VALUES (4, 2, 'El informante', '23:30', '00:30');