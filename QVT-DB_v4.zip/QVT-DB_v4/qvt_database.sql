-- --------------------------------------
-- Inserción de los Usuarios de prueba --
INSERT INTO `qvt-db`.`Usuario` (`username`, `password`, `nombres`, `apellidos`, `email`) VALUES ('admin', 'admin', 'Admin', 'Test', 'admin@test.com');
INSERT INTO `qvt-db`.`Usuario` (`username`, `password`, `nombres`, `apellidos`, `email`) VALUES ('jpsalas1', 'jpsalas1', 'Juan Pedro', 'Pérez Salas', 'jp.perez.salas@gmail.com');

-- --------------------------------------
-- Inserción de los Canales Nacionales --
INSERT INTO `qvt-db`.`Canal` (`nombre`) VALUES ('Canal 13');
INSERT INTO `qvt-db`.`Canal` (`nombre`) VALUES ('Chilevision');
INSERT INTO `qvt-db`.`Canal` (`nombre`) VALUES ('MEGA');
INSERT INTO `qvt-db`.`Canal` (`nombre`) VALUES ('TVN');

-- ---------------------------------------
-- Inserción de Categorias de Programas --
INSERT INTO `qvt-db`.`Categoria` ( `nombre` ) VALUES ('Matinal');
INSERT INTO `qvt-db`.`Categoria` ( `nombre` ) VALUES ('Serie');
INSERT INTO `qvt-db`.`Categoria` ( `nombre` ) VALUES ('Estelar');
INSERT INTO `qvt-db`.`Categoria` ( `nombre` ) VALUES ('Reality');
INSERT INTO `qvt-db`.`Categoria` ( `nombre` ) VALUES ('Serie Legal');
INSERT INTO `qvt-db`.`Categoria` ( `nombre` ) VALUES ('Serie Cocina');
INSERT INTO `qvt-db`.`Categoria` ( `nombre` ) VALUES ('Serie Nacional');

-- -------------------------------------------------------------------------------
-- Inserción de algunos programas transmitidos por sus correspondientes canales --
-- CANAL 13 --
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (1, 1, 'Bienvenidos', "El entretenimiento, noticias de farándula, recetas de cocina y la información necesaria para comenzar el día. Presentadores Tonka Tomicic y Martín Cárcamo.",'08:00', '13:30');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (1, 1, 'Paramparça',"La información del programa no fue provista por el proveedor de la señal.", '15:30', '17:00');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (1, 1, 'Entre dos amores',"La historia de una joven llamada Neriman quien perdió de niña a su madre y vive en un barrio humilde de Estambul, junto a su tía y a su conservador padre. Desde pequeña ha estado enamorada de su amigo Sinasi, quien corresponde estos sentimientos.", '17:00', '18:00');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (1, 1, 'Amor a segunda vista',"Fatih, es un joven millonario que no quiere que su familia lo obligue a casarse con Irem y Zeynep, necesita tiempo para confesar a su familia que es madre soltera. Ellos se encuentran en un vuelo a Turquía y fingirán estar casados.", '18:00', '19:10');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (1, 1, 'La pequeña casa en la pradera',"Una familia de pioneros lucha por sobrevivir en Minnesota alrededor del año 1870.", '19:10', '21:00');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (1, 1, 'Vertigo',"Un programa de entretenimiento, concursos y mucha diversión donde el público televidente escoge mediante votación al mejor invitado de la noche.", '22:35', '01:00');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (1, 1, 'Kosem',"Tomando el nombre de Kosem, que significa líder y guía Anastasia se convertirá en una de las mujeres más poderosas en la historia del Imperio Otomano.", '22:35', '00:15');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (1, 1, 'MasterChef Chile',"Un programa que se ha realizado en más de 145 países presenta la versión chilena, donde 15 chefs aficionados y otros seleccionados entre miles competirán por cumplir el sueño de convertirse en el primer MasterChef de Chile.", '23:30', '01:30');

-- CHILEVISION --
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (2, 2, 'La mañana',"Informativo Diario.", '08:00', '13:30');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (2, 2, 'La jueza',"Carmen Gloria Arroyo analiza y resuelve conflictos legales.", '15:30', '17:30');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (2, 2, 'Lo que callamos las mujeres',"Dramatización de las historias que viven las mujeres en su entorno social.", '17:30', '18:30');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`, `descripcion`,`inicio`, `termino`) VALUES (2, 2, 'Vidas en riesgo',"Los dramas que se viven en el servicio de urgencia de un hospital, las vidas de los médicos su perfil psicológico y cómo se enfrentan a sus casos.", '18:30', '19:30');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (2, 2, 'Caso cerrado',"La abogada Ana María Polo intenta resolver los conflictos y las disputas entre las partes involucradas, los casos que son presentados ante ella son variados, en un escenario que hace las veces de juzgado.", '19:30', '21:00');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (2, 2, 'Espías del amor',"La información del programa no fue provista por el proveedor de la señal.", '22:30', '00:00');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (2, 2, 'Primer plano', "Toda la información sobre el mundo de la farándula de la televisión chilena.",'22:30', '00:30');

-- MEGA --
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (3, 1, 'Mucho gusto',"Un programa que se encarga de llevar información y entretenimiento de una manera muy alegre a los hogares chilenos.", '08:00', '13:00');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (3, 1, 'Amanda',"Amanda buscará librarse de sus miedos y vengarse de la persona que arruinó su vida. Sin embargo, al intentarlo se enamorará de una persona no correspondida.", '15:15', '16:30');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (3, 1, 'Sevda',"La información del programa no fue provista por el proveedor de la señal.", '16:30', '17:15');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (3, 1, 'El regreso de Lucas', "Luego de 20 años de la desaparición de Lucas, llega a manos de la madre una foto de su hijo. Una nueva pista que renueva las esperanzas de Elena de hallar a su hijo. Hasta que un día, un joven se presenta diciendo ser Lucas. ¿Será él su hijo perdido?",'17:15', '18:00');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (3, 1, 'El secreto de Feriha',"Feriha Yilmaz es una chica de orígenes humildes que vive en el sótano de un lujoso edificio. La joven obtiene una beca completa para estudiar en una universidad privada y rápidamente pasa a ser el centro de atención, incluso del playboy de la universidad. ", '18:00', '20:15');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (3, 1, 'Tranquilo papá',"La información del programa no fue provista por el proveedor de la señal.", '20:15', '21:00');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (3, 1, 'Perdona nuestros pecados',"Perdona nuestros pecados es una telenovela chilena de horario nocturno producida y transmitida por Mega. Escrita por Pablo Illanes y Josefina Fernández, y dirigida por Nicolás Alemparte, bajo la supervisión general de María Eugenia Rencoret.", '22:30', '23:30');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (3, 1, 'Morandé con compañia',"Un momento de entretención junto a Kike Morandé y sus bellas modelos.", '22:30', '00:45');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (3, 1, 'Doble tentación',"Reality show donde se pondrá a prueba la fidelidad de siete parejas que, expuestos a una tentación encarnada por espectaculares solteros y solteras, enfrentarán sus verdaderos sentimientos revelando pasiones, fortalezas y debilidades.", '23:30', '01:00');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (3, 1, 'Más vale tarde',"Un programa de entrevistas a distintos artistas del espectáculo quien junto a los invitados opinan sobre las noticias nacionales e internacionales.", '01:00', '02:00');

-- TVN --
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (4, 2, 'Muy buenos días',"Servicios, conversación, humor y la mejor compañía para empezar cada día. ", '08:00', '13:00');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (4, 2, 'Elif', "La criada de una familia se enamora del hijo favorito, queda embarazada y la madre del chico la envía lejos, nace Elif y su padre, quien no sabe de su existencia, se casa con otra, en tanto que su madre se casa con un hombre malvado.",'15:30', '17:15');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (4, 2, 'Saras y Kumud',"Un hombre es forzado por su padre a casarse con una mujer que no conoce. ¿Podrá oponerse a ese designio? Una historia de poder, amor y desengaño en los más impactantes escenarios naturales de Asia y Medio Oriente.", '17:15', '18:30');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (4, 2, 'Günes', "Una mujer que se hizo cargo sola de sus tres hijas decide rehacer su vida cuando ellas se convierten en adolescentes, por lo que conoce a un millonario empresario que le ofrece matrimonio, sin embargo la propuesta originará un drama familiar.",'18:30', '20:00');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (4, 2, 'La colombiana',"Ángela llega de Colombia a Chile en busca de un futuro mejor, pero a su nuevo vecino no le gustan los inmigrantes. Sin embargo, ella le ayuda a recuperar a su exesposa, quien va a casarse con un exitoso empresario, a cambio de que él cuide a su hijo.", '20:00', '21:00');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (4, 2, 'Match',"Personas que han dejado de lado su vida sentimental son ayudados por sus hijos para encontrar pareja, quienes tratan de incentivar a sus progenitores a que tengan una vida social y amorosa con la cooperación del presentador que promueve los nexos.", '22:30', '00:15');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (4, 2, 'Hulya',"Bayram compromete a su hijo Kerim con Melek. Los niños son criados en diferentes ciudades hasta que pueden casarse pero el compromiso se acabará por culpa de Hulya. Ella, logrará casarse con él, aunque no todo saldrá como lo planeó.", '22:45', '23:30');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (4, 2, 'Josue y la tierra prometida',"La historia del pueblo hebreo tras la muerte de Moisés cuando, liderados por Josué, tendrán que enfrentarse a distintos reinos para tomar Canaán, la tierra que Dios les prometió.", '23:30', '00:30');
INSERT INTO `qvt-db`.`Programa` (`canal_id`, `usuario_id`, `nombre`,`descripcion`, `inicio`, `termino`) VALUES (4, 2, 'El informante',"El nuevo programa de debate y actualidad está a cargo de Juan Manuel Astorga. Un espacio para discutir a fondo temas de actualidad y realidad nacional.", '23:30', '00:30');

-- -------------------------------------
-- Inserción de Keywords de Programas --
-- PROGRAMAS CANAL 13 --
-- ID [1-7] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Bienvenidos13');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('HoróscopoBienvenidos');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('BV');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('BV13');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('TiempoBienvenidos');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('PregúntaleAMichelle');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('LaCabinadeLosDeseos');
-- ID [8-21] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Paramparça');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Paramparca');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Gülseren');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Gulseren');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Cihan');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Dilara');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Cansu');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Hazal');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Ozan');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Alpar');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Solmaz');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Özkan');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Ozkan');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Keriman');
-- ID [22-33] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('EntreDosAmores');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Neriman');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Macit');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Sinasi');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Pelin');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Faiz');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Inci');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Gulter');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Kerim');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Selim');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Feyza');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Duygu');
-- ID [34-42] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('AmorASegundaVista');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Zeynep');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Fatih');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Sevket');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Gulsum');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Fehmi');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Mukkades');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Irem');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Selin');
-- ID [43-44] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('LaPequeñaCasaEnLaPradera');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('FamiliaIngalls');
-- ID [45-52] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Vertigo');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Vértigo2017');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Vertigo2017');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('VertigoCanal13');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('BotónDePánico');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Yerko');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('YerkoPuchento');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('JuevesDeVerdad');
-- ID [53-65] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Kosem');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('ComunidadOtomana');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Murad');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Ahmed');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Iskender');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Safiye');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Handan');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Halime');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Fahriye');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('ShahinGiray');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MehmedGiray');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Zulfikar');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Dervish');
-- ID [66-70] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MasterChefChile');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MasterChefChile3');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MasterChef3');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MC');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('CajaMisteriosa');
-- FIN PROGRAMAS CANAL 13 --

-- -----------------------
-- PROGRAMAS CHILEVSION --
-- ID [71-72] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('LaMañana');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('matinaldechv');
-- ID [73-74] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('LaJueza');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('lajuezachv');
-- ID [75-76] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('LoQueCallamosLasMujeres');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Lo_Que_Callamos');
-- ID 77 --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('VidasEnRiesgo');
-- ID 78 --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('CasoCerrado');
-- ID [79-82] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('EspíasDelAmor');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('EspiasDelAmor');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('CatfishChile');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('espiasdelamor');
-- ID [83-84] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('PrimerPlano');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('_PrimerPlano');
-- FIN PROGRAMAS CHILEVISION --

-- -----------------
-- PROGRAMAS MEGA --
-- ID [85-93] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MuchoGustoMEGA');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MuchoGusto');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('DesayunoGustoMG');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('PatrullaJuvenilMG');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('CocinaGustoMG');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('LaPolémicaDelDíaMG');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('LaPolemicaDelDiaMG');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('ConfesionesMatinalesMG');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('LaConversaMG');
-- ID [94-95] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Amanda');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('amandateleserie');
-- ID 96 --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Sevda');
-- ID 97 --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('ElRegresoDeLucas');
-- ID [98-100] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('ElSecretoDeFeriha');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Feriha');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Emir');
-- ID [101-103] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('TranquiloPapá');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('TranquiloPapa');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('TranquiPapaMEGA');
-- ID [104-105] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('PerdonaNuestrosPecados');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('PnpMega');
-- ID [106-113] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MorandéConCompañia');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MorandeConCompañia');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MCCoficial');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MCC');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MCC2017');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MCCEstelar');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('ElMuro');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('KikeMorandé');
-- ID [114-117] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('DobleTentación');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('DobleTentacion');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('DobleTentacionM');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('NocheDeMemes');
-- ID [118-122] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MásValeTarde');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MasValeLate');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MVT');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('LaVozDeLaCalle');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('LaCarta');
-- FIN PROGRAMAS MEGA --

-- ----------------
-- PROGRAMAS TVN --
-- ID [123-127] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MuyBuenosDías');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MuyBuenosDias');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MuyBuenosDíasTVN');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('BuenosDiasTVN');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('buenosdiastvn2');
-- ID [128-140] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Elif');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('ElifTVN');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Melek');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Kenan');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Arzu');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Aliye');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Tügce');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Tugce');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Selim');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Zeynep');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Murat');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Veysel');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Gonca');
-- ID [141-144] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('SarasYKumud');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('sarasykumudTV');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Saras');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Kumud');
-- ID [145-151] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Günes');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('GunesTVN');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Gunes');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Haluk');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Nazli');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Ali');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Savas');
-- ID [152-153] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('LaColombiana');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('LaColombianaTVN');
-- ID [154-155] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Match');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('MatchTVN');
-- ID [156-160] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Hulya');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('HulyaTVN');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Bayram');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Kerim');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Huseyin');
-- ID [161-166] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('JosueYLaTierraPrometida');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('JosueTVN');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Josue');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Aruna');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Marek');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('Kalesi');
-- ID [167-168] --
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('ElInformante');
INSERT INTO `qvt-db`.`Keyword` ( `keyword` ) VALUES ('ElInformanteTVN');
-- FIN PROGRAMAS TVN --

-- -------------------------------------------
-- Asociación de Programas con su Categoria --
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (1,1);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (2,2);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (3,2);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (4,2);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (5,2);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (6,3);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (7,2);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (8,6);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (9,1);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (10,5);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (11,2);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (12,2);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (13,5);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (14,4);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (15,3);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (16,1);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (17,7);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (18,2);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (19,2);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (20,2);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (21,7);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (22,7);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (23,3);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (24,4);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (25,2);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (26,1);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (27,2);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (28,2);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (29,2);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (30,7);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (31,3);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (32,2);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (33,2);
INSERT INTO `qvt-db`.`Programa_Categoria` ( `programa_id`,`categoria_id` ) VALUES (34,2);

-- -----------------------------------------
-- Asociación de Programas con su Keyword --
-- CANAL 13 --
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (1,1);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (1,2);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (1,3);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (1,4);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (1,5);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (1,6);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (1,7);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (2,8);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (2,9);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (2,10);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (2,11);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (2,12);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (2,13);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (2,14);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (2,15);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (2,16);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (2,17);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (2,18);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (2,19);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (2,20);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (2,21);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (3,22);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (3,23);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (3,24);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (3,25);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (3,26);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (3,27);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (3,28);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (3,29);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (3,30);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (3,31);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (3,32);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (3,33);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (4,34);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (4,35);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (4,36);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (4,37);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (4,38);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (4,39);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (4,40);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (4,41);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (4,42);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (5,43);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (5,44);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (6,45);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (6,46);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (6,47);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (6,48);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (6,49);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (6,50);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (6,51);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (6,52);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (7,53);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (7,54);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (7,55);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (7,56);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (7,57);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (7,58);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (7,59);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (7,60);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (7,61);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (7,62);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (7,63);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (7,64);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (7,65);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (8,66);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (8,67);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (8,68);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (8,69);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (8,70);
-- CHILEVISION --
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (9,71);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (9,72);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (10,73);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (10,74);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (11,75);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (11,76);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (12,77);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (13,78);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (14,79);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (14,80);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (14,81);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (14,82);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (15,83);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (15,84);
-- MEGA --
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (16,85);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (16,86);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (16,87);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (16,88);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (16,89);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (16,90);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (16,91);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (16,92);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (16,93);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (17,94);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (17,95);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (18,96);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (19,97);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (20,98);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (20,99);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (20,100);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (21,101);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (21,102);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (21,103);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (22,104);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (22,105);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (23,106);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (23,107);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (23,108);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (23,109);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (23,110);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (23,111);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (23,112);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (23,113);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (24,114);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (24,115);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (24,116);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (24,117);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (25,118);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (25,119);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (25,120);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (25,121);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (25,122);
-- TVN --
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (26,123);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (26,124);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (26,125);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (26,126);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (26,127);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (27,128);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (27,129);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (27,130);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (27,131);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (27,132);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (27,133);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (27,134);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (27,135);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (27,136);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (27,137);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (27,138);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (27,139);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (27,140);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (28,141);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (28,142);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (28,143);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (28,144);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (29,145);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (29,146);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (29,147);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (29,148);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (29,149);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (29,150);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (29,151);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (30,152);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (30,153);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (31,154);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (31,155);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (32,156);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (32,157);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (32,158);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (32,159);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (32,160);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (33,161);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (33,162);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (33,163);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (33,164);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (33,165);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (33,166);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (34,167);
INSERT INTO `qvt-db`.`Programa_Keyword` ( `programa_id`,`keyword_id` ) VALUES (34,168);
--